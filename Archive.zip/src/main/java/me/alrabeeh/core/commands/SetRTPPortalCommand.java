package me.alrabeeh.core.commands;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.alrabeeh.core.managers.PluginManager;
import me.alrabeeh.core.permissions.ModAdminPermissions;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;

public class SetRTPPortalCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        if (!player.hasPermission("alrabeehcore.admin.setrtpportal")) {
            Component message = Utils.colorize("<red>You don't have permission to use this command.</red>");
            player.sendMessage(message);
            return true;
        }

        Location location = player.getLocation();
        PluginManager.getInstance().setRTPPortalLocation(location);

        Component message = Utils.colorize("<green>RTP Portal location set to your current position!</green>");
        player.sendMessage(message);
        return true;
    }
}