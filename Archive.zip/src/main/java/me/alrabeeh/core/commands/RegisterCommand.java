package me.alrabeeh.core.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import me.alrabeeh.core.managers.PluginManager;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import org.bukkit.plugin.RegisteredServiceProvider;

public class RegisterCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        if (args.length != 3) {
            Component message = Utils.colorize("<red>/register (first name) (school email) (password)</red>");
            player.sendMessage(message);
            return true;
        }

        String firstName = args[0];
        String email = args[1];
        String password = args[2];

        if (!email.contains("@")) {
            Component message = Utils.colorize("<red>Invalid email format!</red>");
            player.sendMessage(message);
            return true;
        }

        if (PluginManager.getInstance().getAuthDatabase().isRegistered(player.getName())) {
            Component message = Utils.colorize("<red>You are already registered!</red>");
            player.sendMessage(message);
            return true;
        }

        PluginManager.getInstance().getAuthDatabase().registerUser(player.getName(), email, password);
        PluginManager.getInstance().setAuthenticated(player.getUniqueId(), true);

        // Remove blindness
        player.removePotionEffect(PotionEffectType.BLINDNESS);

        // Add to LuckPerms student group asynchronously
        org.bukkit.Bukkit.getScheduler().runTaskAsynchronously(
            org.bukkit.Bukkit.getPluginManager().getPlugin("AlRabeehCore"),
            () -> addToStudentGroup(player)
        );

        Component message = Utils.colorize("<green>Registration successful! Welcome to Al Rabeeh!</green>");
        player.sendMessage(message);

        return true;
    }

    private void addToStudentGroup(Player player) {
        try {
            RegisteredServiceProvider<LuckPerms> provider = org.bukkit.Bukkit.getServicesManager().getRegistration(LuckPerms.class);
            if (provider != null) {
                LuckPerms luckPerms = provider.getProvider();
                User user = luckPerms.getUserManager().loadUser(player.getUniqueId()).join();
                if (user != null) {
                    user.data().add(Node.builder("group.student").build());
                    luckPerms.getUserManager().saveUser(user);
                }
            }
        } catch (Exception e) {
            org.bukkit.Bukkit.getLogger().warning("[AlRabeehCore] Failed to add player to student group: " + e.getMessage());
        }
    }
}
