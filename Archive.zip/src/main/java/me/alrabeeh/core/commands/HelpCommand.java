package me.alrabeeh.core.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;

public class HelpCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Component help = Utils.colorize("<gold>Al Rabeeh Core Commands:</gold>\n" +
                "<yellow>/support</yellow> - Get help from school forums\n" +
                "<yellow>/sethome</yellow> - Manage your homes\n" +
                "<yellow>/register</yellow> - Register your account\n" +
                "<yellow>/login</yellow> - Login to your account\n" +
                "<yellow>/help</yellow> - Show this help menu");
        sender.sendMessage(help);
        return true;
    }
}
