package me.alrabeeh.core.commands;

import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import me.alrabeeh.core.permissions.ModAdminPermissions;

public class RTPStickCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        if (!player.hasPermission("alrabeehcore.admin.rtpstick")) {
            Component message = Utils.colorize("<red>You don't have permission to use this command.</red>");
            player.sendMessage(message);
            return true;
        }

        ItemStack stick = new ItemStack(Material.STICK);
        ItemMeta meta = stick.getItemMeta();
        meta.displayName(Utils.colorize("<gold>RTP Portal Selector"));
        meta.lore(java.util.Arrays.asList(
            Utils.colorize("<gray>Right-click corners to select portal area"),
            Utils.colorize("<gray>First click: Position 1"),
            Utils.colorize("<gray>Second click: Position 2")
        ));
        stick.setItemMeta(meta);

        player.getInventory().addItem(stick);

        Component message = Utils.colorize("<green>RTP Portal Selector stick given! Right-click two diagonal corners of the portal area.</green>");
        player.sendMessage(message);
        return true;
    }
}