package me.alrabeeh.core.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;

public class SupportCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        // Create clickable link to school forums
        Component message = Utils.colorize("<green>Need help? Visit our school forums: </green>")
                .append(Component.text("https://school-forums.example.com")
                        .clickEvent(ClickEvent.openUrl("https://school-forums.example.com")));

        player.sendMessage(message);
        return true;
    }
}