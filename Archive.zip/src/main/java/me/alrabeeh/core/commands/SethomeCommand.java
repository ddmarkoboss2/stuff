package me.alrabeeh.core.commands;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import me.alrabeeh.core.managers.PluginManager;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;

public class SethomeCommand implements CommandExecutor {
    private final JavaPlugin plugin;
    private final Map<UUID, Integer> delionSlotPending = new ConcurrentHashMap<>();

    public SethomeCommand(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        if (args.length == 0) {
            // Open GUI
            openSethomeGUI(player);
            return true;
        }

        if (args.length < 1) {
            player.sendMessage("Usage: /sethome [slot] [set|delete|tp|confirm]");
            return true;
        }

        try {
            int slot = Integer.parseInt(args[0]);
            if (slot < 1 || slot > 7) {
                Component message = Utils.colorize("<red>Slot must be between 1 and 7!</red>");
                player.sendMessage(message);
                return true;
            }

            if (args.length == 1) {
                // Assume just 'tp' if only slot is given
                teleportHome(player, slot);
                return true;
            }

            String action = args[1].toLowerCase();

            switch (action) {
                case "set":
                    setHome(player, slot);
                    break;
                case "delete":
                    deleteHome(player, slot);
                    break;
                case "tp":
                    teleportHome(player, slot);
                    break;
                case "confirm":
                    confirmDelete(player, slot);
                    break;
                default:
                    player.sendMessage("Usage: /sethome [slot] [set|delete|tp|confirm]");
            }
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid slot number!");
        }

        return true;
    }

    private void openSethomeGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, Utils.colorize("<gold>Sethome Menu</gold>"));

        for (int i = 0; i < 7; i++) {
            int slot = i + 1;
            boolean hasHome = PluginManager.getInstance().getSethomeDatabase().hasHome(player.getName(), slot);

            // Bed
            ItemStack bed = new ItemStack(hasHome ? Material.GREEN_BED : Material.RED_BED);
            ItemMeta bedMeta = bed.getItemMeta();
            bedMeta.displayName(Utils.colorize(hasHome ? "<green>Home " + slot : "<red>Home " + slot + " - Not Set"));
            bed.setItemMeta(bedMeta);

            // Dye
            ItemStack dye = new ItemStack(hasHome ? Material.GREEN_DYE : Material.RED_DYE);
            ItemMeta dyeMeta = dye.getItemMeta();
            dyeMeta.displayName(Utils.colorize(hasHome ? "<green>Delete Home " + slot : "<red>Set Home " + slot));
            dye.setItemMeta(dyeMeta);

            inv.setItem(i * 2, bed);
            inv.setItem(i * 2 + 1, dye);
        }

        player.openInventory(inv);
    }

    private void setHome(Player player, int slot) {
        if (PluginManager.getInstance().getSethomeDatabase().hasHome(player.getName(), slot)) {
            Component message = Utils.colorize("<red>Home " + slot + " already exists! Do /sethome " + slot + " delete first!</red>");
            player.sendMessage(message);
            return;
        }

        Location loc = player.getLocation();
        PluginManager.getInstance().getSethomeDatabase().setHome(player.getName(), slot, loc);
        Component message = Utils.colorize("<green>Home " + slot + " set successfully at your current location!</green>");
        player.sendMessage(message);
    }

    private void deleteHome(Player player, int slot) {
        if (!PluginManager.getInstance().getSethomeDatabase().hasHome(player.getName(), slot)) {
            Component message = Utils.colorize("<red>Home " + slot + " is not set!</red>");
            player.sendMessage(message);
            return;
        }

        delionSlotPending.put(player.getUniqueId(), slot);
        Component message = Utils.colorize("<red>Please run /sethome " + slot + " confirm to confirm the deletion.</red>");
        player.sendMessage(message);

        // Send reminders at 5s, 10s, 13s
        sendDeleteReminders(player, slot);
    }

    private void sendDeleteReminders(Player player, int slot) {
        UUID playerId = player.getUniqueId();

        // 5 second reminder
        new BukkitRunnable() {
            @Override
            public void run() {
                if (delionSlotPending.containsKey(playerId)) {
                    player.sendMessage(Utils.colorize("<red>Please run /sethome " + slot + " confirm to confirm the deletion.</red>"));
                }
            }
        }.runTaskLater(plugin, 100);

        // 10 second reminder
        new BukkitRunnable() {
            @Override
            public void run() {
                if (delionSlotPending.containsKey(playerId)) {
                    player.sendMessage(Utils.colorize("<red>Please run /sethome " + slot + " confirm to confirm the deletion.</red>"));
                }
            }
        }.runTaskLater(plugin, 200);

        // 13 second reminder (last one)
        new BukkitRunnable() {
            @Override
            public void run() {
                if (delionSlotPending.containsKey(playerId)) {
                    player.sendMessage(Utils.colorize("<red>Please run /sethome " + slot + " confirm to confirm the deletion (LAST CALL).</red>"));
                }
            }
        }.runTaskLater(plugin, 260);

        // 10 second timeout (23 seconds total after last reminder)
        new BukkitRunnable() {
            @Override
            public void run() {
                if (delionSlotPending.remove(playerId) != null) {
                    player.sendMessage(Utils.colorize("<yellow>Delete request cancelled.</yellow>"));
                }
            }
        }.runTaskLater(plugin, 460); // 23 seconds
    }

    private void teleportHome(Player player, int slot) {
        Location home = PluginManager.getInstance().getSethomeDatabase().getHome(player.getName(), slot);
        if (home == null) {
            Component message = Utils.colorize("<red>Home " + slot + " is not set!</red>");
            player.sendMessage(message);
            return;
        }

        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 0, false, false));
        Component message = Utils.colorize("<yellow>Teleporting in 5 seconds... Stay still!</yellow>");
        player.sendMessage(message);

        new BukkitRunnable() {
            int count = 5;

            @Override
            public void run() {
                if (count == 0) {
                    Location playerLoc = player.getLocation();
                    Location homeLoc = home.clone();
                    homeLoc.setPitch(playerLoc.getPitch());
                    homeLoc.setYaw(playerLoc.getYaw());
                    player.teleport(homeLoc);
                    Component msg = Utils.colorize("<green>Teleported to home " + slot + "!</green>");
                    player.sendMessage(msg);
                    cancel();
                    return;
                }

                if (!player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
                    player.sendMessage(Utils.colorize("<red>Teleport cancelled!</red>"));
                    cancel();
                    return;
                }

                count--;
            }
        }.runTaskTimer(plugin, 0, 20);
    }

    private void confirmDelete(Player player, int slot) {
        Integer pendingSlot = delionSlotPending.remove(player.getUniqueId());
        if (pendingSlot == null || pendingSlot != slot) {
            Component message = Utils.colorize("<red>No pending deletion for slot " + slot + "!</red>");
            player.sendMessage(message);
            return;
        }

        PluginManager.getInstance().getSethomeDatabase().deleteHome(player.getName(), slot);
        Component message = Utils.colorize("<green>Home " + slot + " deleted successfully!</green>");
        player.sendMessage(message);
    }
}
