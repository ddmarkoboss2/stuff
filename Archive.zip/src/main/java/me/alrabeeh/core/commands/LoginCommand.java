package me.alrabeeh.core.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import me.alrabeeh.core.managers.PluginManager;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;

public class LoginCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        if (args.length != 1) {
            Component message = Utils.colorize("<red>/login (password)</red>");
            player.sendMessage(message);
            return true;
        }

        String password = args[0];

        if (!PluginManager.getInstance().getAuthDatabase().isRegistered(player.getName())) {
            Component message = Utils.colorize("<red>You are not registered! Use /register</red>");
            player.sendMessage(message);
            return true;
        }

        if (!PluginManager.getInstance().getAuthDatabase().verifyPassword(player.getName(), password)) {
            Component message = Utils.colorize("<red>Incorrect password!</red>");
            player.sendMessage(message);
            return true;
        }

        PluginManager.getInstance().setAuthenticated(player.getUniqueId(), true);
        player.removePotionEffect(PotionEffectType.BLINDNESS);

        Component message = Utils.colorize("<green>Login successful! Welcome back!</green>");
        player.sendMessage(message);

        return true;
    }
}
