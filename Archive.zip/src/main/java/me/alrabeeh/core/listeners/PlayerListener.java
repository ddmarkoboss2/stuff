package me.alrabeeh.core.listeners;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;

import me.alrabeeh.core.AlRabeehCore;
import me.alrabeeh.core.managers.PluginManager;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;

public class PlayerListener implements Listener {
    
    private final AlRabeehCore plugin;
    
    public PlayerListener(AlRabeehCore plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        // Set join time for chat delay
        PluginManager.getInstance().setPlayerJoinTime(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }
    
    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        long joinTime = PluginManager.getInstance().getPlayerJoinTime(event.getPlayer().getUniqueId());
        long currentTime = System.currentTimeMillis();
        
        if (currentTime - joinTime < 2000) { // 2 seconds
            event.setCancelled(true);
            int remainingSeconds = (int) ((2000 - (currentTime - joinTime)) / 1000) + 1;
            Component message = Utils.colorize("<red>You must wait " + remainingSeconds + " second(s) before chatting.</red>");
            event.getPlayer().sendMessage(message);
        } else {
            // Remove the join time after 2 seconds to prevent memory leak
            PluginManager.getInstance().removePlayerJoinTime(event.getPlayer().getUniqueId());
            
            // Format message with LuckPerms group prefix using color codes
            String groupWithColor = getGroupPrefixWithColor(event.getPlayer());
            String username = event.getPlayer().getName();
            String originalMessage = event.getMessage();
            
            String formattedMessage = groupWithColor + " " + username + ": " + originalMessage;
            
            // Update the format for all players to see
            event.setFormat("%s");
            
            // Send the formatted message
            for (org.bukkit.entity.Player player : event.getPlayer().getServer().getOnlinePlayers()) {
                player.sendMessage(Component.text(formattedMessage));
            }
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onPlayerPortal(PlayerPortalEvent event) {
        // Trigger BetterRTP when entering the specific nether portal
        if (event.getCause() == PlayerPortalEvent.TeleportCause.NETHER_PORTAL) {
            Location from = event.getFrom();
            Location pos1 = PluginManager.getInstance().getRTPPos1();
            Location pos2 = PluginManager.getInstance().getRTPPos2();
            
            if (pos1 != null && pos2 != null && pos1.getWorld().equals(pos2.getWorld()) && from.getWorld().equals(pos1.getWorld())) {
                int minX = Math.min(pos1.getBlockX(), pos2.getBlockX());
                int maxX = Math.max(pos1.getBlockX(), pos2.getBlockX());
                int minY = Math.min(pos1.getBlockY(), pos2.getBlockY());
                int maxY = Math.max(pos1.getBlockY(), pos2.getBlockY());
                int minZ = Math.min(pos1.getBlockZ(), pos2.getBlockZ());
                int maxZ = Math.max(pos1.getBlockZ(), pos2.getBlockZ());
                
                if (from.getBlockX() >= minX && from.getBlockX() <= maxX &&
                    from.getBlockY() >= minY && from.getBlockY() <= maxY &&
                    from.getBlockZ() >= minZ && from.getBlockZ() <= maxZ) {
                    event.setCancelled(true);
                    // Perform RTP command
                    event.getPlayer().performCommand("rtp");
                }
            }
        }
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction().toString().contains("RIGHT_CLICK") && event.getItem() != null) {
            ItemStack item = event.getItem();
            if (item.getType() == Material.STICK && item.hasItemMeta()) {
                ItemMeta meta = item.getItemMeta();
                if (meta.hasDisplayName() && meta.displayName() != null) {
                    Component displayName = meta.displayName();
                    Component expectedName = Utils.colorize("<gold>RTP Portal Selector");
                    
                    // Compare components as strings
                    if (displayName.equals(expectedName)) {
                        event.setCancelled(true);
                        Player player = event.getPlayer();
                        Location clicked = event.getClickedBlock() != null ? event.getClickedBlock().getLocation() : player.getLocation();
                        
                        if (PluginManager.getInstance().getRTPPos1() == null) {
                            PluginManager.getInstance().setRTPPos1(clicked);
                            Component message = Utils.colorize("<green>Position 1 set! Now right-click the opposite corner.</green>");
                            player.sendMessage(message);
                        } else if (PluginManager.getInstance().getRTPPos2() == null) {
                            PluginManager.getInstance().setRTPPos2(clicked);
                            Component message = Utils.colorize("<green>Position 2 set! RTP Portal area selected.</green>");
                            player.sendMessage(message);
                    
                    // Visualize the selected area with green stained glass
                    Location pos1 = PluginManager.getInstance().getRTPPos1();
                    int minX = Math.min(pos1.getBlockX(), clicked.getBlockX());
                    int maxX = Math.max(pos1.getBlockX(), clicked.getBlockX());
                    int minY = Math.min(pos1.getBlockY(), clicked.getBlockY());
                    int maxY = Math.max(pos1.getBlockY(), clicked.getBlockY());
                    int minZ = Math.min(pos1.getBlockZ(), clicked.getBlockZ());
                    int maxZ = Math.max(pos1.getBlockZ(), clicked.getBlockZ());
                    
                    for (int x = minX; x <= maxX; x++) {
                        for (int y = minY; y <= maxY; y++) {
                            for (int z = minZ; z <= maxZ; z++) {
                                // Only show edges for better visibility
                                if ((x == minX || x == maxX) && (y == minY || y == maxY) ||
                                    (z == minZ || z == maxZ) && (x == minX || x == maxX || y == minY || y == maxY)) {
                                    Location loc = new Location(clicked.getWorld(), x, y, z);
                                    player.sendBlockChange(loc, Material.GREEN_STAINED_GLASS.createBlockData());
                                }
                            }
                        }
                    }
                    
                    // Hide after 10 seconds
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        for (int x = minX; x <= maxX; x++) {
                            for (int y = minY; y <= maxY; y++) {
                                for (int z = minZ; z <= maxZ; z++) {
                                    Location loc = new Location(clicked.getWorld(), x, y, z);
                                    player.sendBlockChange(loc, loc.getBlock().getBlockData());
                                }
                            }
                        }
                    }, 200L); // 10 seconds
                } else {
                    Component message = Utils.colorize("<red>Portal area already set! Use /setrtpportal to reset.</red>");
                    player.sendMessage(message);
                }
                    }
                }
            }
        }
    }    
    private String getGroupPrefixWithColor(org.bukkit.entity.Player player) {
        try {
            RegisteredServiceProvider<net.luckperms.api.LuckPerms> provider = 
                org.bukkit.Bukkit.getServicesManager().getRegistration(net.luckperms.api.LuckPerms.class);
            
            if (provider != null) {
                net.luckperms.api.LuckPerms luckPerms = provider.getProvider();
                net.luckperms.api.model.user.User user = luckPerms.getUserManager().getUser(player.getUniqueId());
                
                if (user != null) {
                    String primaryGroup = user.getPrimaryGroup();
                    if (primaryGroup != null && !primaryGroup.isEmpty()) {
                        // Capitalize group name for display
                        String displayName = primaryGroup.substring(0, 1).toUpperCase() + primaryGroup.substring(1);
                        
                        // Use the group name as the color hint (set as meta "prefix" on the LuckPerms group)
                        // For now, just use the primary group name as the color code
                        return me.alrabeeh.core.utils.ColorMapper.formatGroupPrefix(displayName, primaryGroup);
                    }
                }
            }
        } catch (Exception e) {
            // Return default
        }
        return "[§fMember§r]";
    }}