package me.alrabeeh.core.listeners;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import me.alrabeeh.core.managers.PluginManager;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;

public class InventoryListener implements Listener {
    private final JavaPlugin plugin;

    public InventoryListener(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;

        String title = event.getView().getTitle();
        if (!title.contains("Sethome") && !title.contains("Confirm")) {
            return;
        }

        event.setCancelled(true);
        Player player = (Player) event.getWhoClicked();
        ItemStack clicked = event.getCurrentItem();

        if (clicked == null || clicked.getType() == Material.AIR) return;

        if (title.contains("Sethome")) {
            handleSethomeClick(player, clicked, event.getRawSlot());
        } else if (title.contains("Confirm")) {
            handleConfirmClick(player, clicked);
        }
    }

    private void handleSethomeClick(Player player, ItemStack clicked, int slot) {
        int homeIndex = slot / 2;
        if (homeIndex < 0 || homeIndex >= 7) return;

        int homeSlot = homeIndex + 1;
        Material material = clicked.getType();

        if (material == Material.RED_BED || material == Material.GREEN_BED) {
            // Teleport to home
            Location home = PluginManager.getInstance().getSethomeDatabase().getHome(player.getName(), homeSlot);
            if (home == null) {
                Component message = Utils.colorize("<red>Home " + homeSlot + " is not set!</red>");
                player.sendMessage(message);
                return;
            }

            // Add slowness and start teleport timer
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 0, false, false));
            Component message = Utils.colorize("<yellow>Teleporting in 3 seconds... Stay still!</yellow>");
            player.sendMessage(message);

            new BukkitRunnable() {
                int count = 3;

                @Override
                public void run() {
                    if (count == 0) {
                        Location playerLoc = player.getLocation();
                        Location homeLoc = home.clone();
                        homeLoc.setPitch(playerLoc.getPitch());
                        homeLoc.setYaw(playerLoc.getYaw());
                        player.teleport(homeLoc);
                        Component msg = Utils.colorize("<green>Teleported to home " + homeSlot + "!</green>");
                        player.sendMessage(msg);
                        cancel();
                        return;
                    }
                    
                    if (!player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
                        player.sendMessage(Utils.colorize("<red>Teleport cancelled!</red>"));
                        cancel();
                        return;
                    }

                    count--;
                }
            }.runTaskTimer(plugin, 0, 20);

            player.closeInventory();
        } else if (material == Material.RED_DYE || material == Material.GREEN_DYE) {
            // Set or delete home
            if (PluginManager.getInstance().getSethomeDatabase().hasHome(player.getName(), homeSlot)) {
                // Show delete confirmation
                showDeleteConfirmation(player, homeSlot);
            } else {
                // Set home
                PluginManager.getInstance().getSethomeDatabase().setHome(player.getName(), homeSlot, player.getLocation());
                Component message = Utils.colorize("<green>Home " + homeSlot + " set successfully!</green>");
                player.sendMessage(message);
                player.closeInventory();
            }
        }
    }

    private void showDeleteConfirmation(Player player, int homeSlot) {
        //TODO: Implement delete confirmation GUI
    }

    private void handleConfirmClick(Player player, ItemStack clicked) {
        // TODO: Implement confirmation logic
    }
}
