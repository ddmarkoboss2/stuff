package me.alrabeeh.core.listeners;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import me.alrabeeh.core.managers.PluginManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

public class AuthListener implements Listener {

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        if (!PluginManager.getInstance().isAuthenticated(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Component.text("You must login first!", NamedTextColor.RED));
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (!PluginManager.getInstance().isAuthenticated(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        // Apply blindness to unauthenticated players
        if (!PluginManager.getInstance().isAuthenticated(event.getPlayer().getUniqueId())) {
            final org.bukkit.entity.Player player = event.getPlayer();

            // Determine whether player is already registered (show login) or not (show register)
            boolean tmpRegistered = false;
            try {
                tmpRegistered = PluginManager.getInstance().getAuthDatabase().isRegistered(player.getName());
            } catch (Exception ignored) {
            }
            final boolean isRegistered = tmpRegistered;

            // Apply max blindness (amplifier 4 = maximum vision blocking)
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 4, false, false));

            // Show auth message immediately (login if registered, register otherwise)
            showAuthMessage(player, isRegistered);

            // Schedule message to repeat every 10 seconds
            int taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(
                Bukkit.getPluginManager().getPlugin("AlRabeehCore"),
                () -> {
                    if (!PluginManager.getInstance().isAuthenticated(player.getUniqueId())) {
                        showAuthMessage(player, isRegistered);
                    }
                },
                0L,
                200L
            );

            // Store task ID to cancel later when they auth
            PluginManager.getInstance().setBlindnessTaskId(player.getUniqueId(), taskId);
        }
    }

    private void showAuthMessage(org.bukkit.entity.Player player, boolean isLogin) {
        if (isLogin) {
            Component message = Component.text("Please login with ")
                    .color(NamedTextColor.RED)
                    .append(Component.text("/login (your-password)")
                            .color(NamedTextColor.WHITE));
            player.sendActionBar(message);
            player.sendMessage(message);
        } else {
            Component message = Component.text("Please register with ")
                    .color(NamedTextColor.RED)
                    .append(Component.text("/register (first name) (school email) (your-password)")
                            .color(NamedTextColor.WHITE));
            player.sendActionBar(message);
            player.sendMessage(message);
        }
    }
}
