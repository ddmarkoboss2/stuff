package me.alrabeeh.core.listeners;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffectType;

import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;

public class MovementListener implements Listener {
    private final Map<UUID, Location> lastLocation = new ConcurrentHashMap<>();

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        // Skip if player is teleporting
        if (event.getTo() == null) return;

        UUID playerId = event.getPlayer().getUniqueId();
        Location from = event.getFrom();
        Location to = event.getTo();

        // Check if player moved significantly
        if (!isSameBlock(from, to)) {
            if (event.getPlayer().hasPotionEffect(PotionEffectType.SLOWNESS)) {
                event.getPlayer().removePotionEffect(PotionEffectType.SLOWNESS);
                Component message = Utils.colorize("<red>Teleport cancelled! You moved!</red>");
                event.getPlayer().sendMessage(message);
            }
        }
    }

    private boolean isSameBlock(Location loc1, Location loc2) {
        return loc1.getBlockX() == loc2.getBlockX() &&
               loc1.getBlockY() == loc2.getBlockY() &&
               loc1.getBlockZ() == loc2.getBlockZ() &&
               loc1.getWorld() == loc2.getWorld();
    }
}
