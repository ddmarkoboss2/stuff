package me.alrabeeh.core.permissions;

public class ModAdminPermissions {

    // RTP Portal Management
    public static final String RTP_STICK = "alrabeehcore.admin.rtpstick";
    public static final String SET_RTP_PORTAL = "alrabeehcore.admin.setrtpportal";

    // Support and Help
    public static final String HELP_COMMAND = "alrabeehcore.help";

    // Sethome (if admin only, but probably player)
    // For now, assume sethome is for players

    // Authentication (admin to manage?)
    // Perhaps admin can reset passwords or something, but for now, players use /register /login
}
