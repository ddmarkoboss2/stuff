package me.alrabeeh.core.database;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class SethomeDatabase {
    private final JavaPlugin plugin;
    private final File sethomeFile;
    private final Map<String, Map<Integer, Location>> homes = new ConcurrentHashMap<>();

    public SethomeDatabase(JavaPlugin plugin) {
        this.plugin = plugin;
        this.sethomeFile = new File(plugin.getDataFolder(), "sethomes.db");
        loadData();
    }

    public void setHome(String username, int slot, Location location) {
        if (slot < 1 || slot > 7) return;
        Map<Integer, Location> playerHomes = homes.computeIfAbsent(username.toLowerCase(), k -> new ConcurrentHashMap<>());
        playerHomes.put(slot, location);
        saveAsync();
    }

    public Location getHome(String username, int slot) {
        Map<Integer, Location> playerHomes = homes.get(username.toLowerCase());
        if (playerHomes == null) return null;
        return playerHomes.get(slot);
    }

    public void deleteHome(String username, int slot) {
        Map<Integer, Location> playerHomes = homes.get(username.toLowerCase());
        if (playerHomes != null) {
            playerHomes.remove(slot);
            saveAsync();
        }
    }

    public boolean hasHome(String username, int slot) {
        Map<Integer, Location> playerHomes = homes.get(username.toLowerCase());
        return playerHomes != null && playerHomes.containsKey(slot);
    }

    private void loadData() {
        if (!sethomeFile.exists()) {
            plugin.getDataFolder().mkdirs();
            return;
        }

        try {
            List<String> lines = java.nio.file.Files.readAllLines(sethomeFile.toPath());
            for (String line : lines) {
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] parts = line.split("\\|");
                if (parts.length == 6) {
                    String username = parts[0];
                    int slot = Integer.parseInt(parts[1]);
                    String world = parts[2];
                    double x = Double.parseDouble(parts[3]);
                    double y = Double.parseDouble(parts[4]);
                    double z = Double.parseDouble(parts[5]);

                    Location loc = new Location(plugin.getServer().getWorld(world), x, y, z);
                    Map<Integer, Location> playerHomes = homes.computeIfAbsent(username.toLowerCase(), k -> new ConcurrentHashMap<>());
                    playerHomes.put(slot, loc);
                }
            }
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to load sethome database: " + e.getMessage());
        }
    }

    private void saveAsync() {
        new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    plugin.getDataFolder().mkdirs();
                    List<String> lines = new ArrayList<>();
                    lines.add("# AlRabeeh Core Sethome Database");
                    for (Map.Entry<String, Map<Integer, Location>> entry : homes.entrySet()) {
                        String username = entry.getKey();
                        for (Map.Entry<Integer, Location> homeEntry : entry.getValue().entrySet()) {
                            int slot = homeEntry.getKey();
                            Location loc = homeEntry.getValue();
                            lines.add(username + "|" + slot + "|" + loc.getWorld().getName() + "|" + loc.getX() + "|" + loc.getY() + "|" + loc.getZ());
                        }
                    }
                    java.nio.file.Files.write(sethomeFile.toPath(), lines, StandardCharsets.UTF_8);
                } catch (IOException e) {
                    plugin.getLogger().warning("Failed to save sethome database: " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(plugin);
    }
}
