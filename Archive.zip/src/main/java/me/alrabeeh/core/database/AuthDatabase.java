package me.alrabeeh.core.database;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class AuthDatabase {
    private final JavaPlugin plugin;
    private final File dbFile;
    private final Map<String, AuthUser> cache = new ConcurrentHashMap<>();
    private Connection connection;

    public AuthDatabase(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dbFile = new File(plugin.getDataFolder(), "auth.db");
        initializeDatabase();
        loadDataAsync();
    }

    private synchronized void initializeDatabase() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "username TEXT UNIQUE NOT NULL COLLATE NOCASE," +
                        "email TEXT NOT NULL," +
                        "password_hash TEXT NOT NULL," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ")");
                stmt.execute("CREATE INDEX IF NOT EXISTS idx_username ON users(username COLLATE NOCASE)");
            }
            plugin.getLogger().info("[AlRabeehCore] SQLite database initialized successfully!");
        } catch (ClassNotFoundException | SQLException e) {
            plugin.getLogger().warning("[AlRabeehCore] Failed to initialize SQLite database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadDataAsync() {
        new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    synchronized (AuthDatabase.this) {
                        if (connection == null || connection.isClosed()) return;
                        
                        String query = "SELECT username, email, password_hash FROM users";
                        try (Statement stmt = connection.createStatement();
                             ResultSet rs = stmt.executeQuery(query)) {
                            
                            while (rs.next()) {
                                String username = rs.getString("username");
                                String email = rs.getString("email");
                                String hash = rs.getString("password_hash");
                                cache.put(username.toLowerCase(), new AuthUser(username, email, hash));
                            }
                        }
                        plugin.getLogger().info("[AlRabeehCore] Loaded " + cache.size() + " users from database");
                    }
                } catch (SQLException e) {
                    plugin.getLogger().warning("[AlRabeehCore] Failed to load users: " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(plugin);
    }

    public void registerUser(String username, String email, String password) {
        String hashedPassword = hashPassword(password);
        AuthUser user = new AuthUser(username, email, hashedPassword);
        cache.put(username.toLowerCase(), user);
        saveUserAsync(username, email, hashedPassword);
    }

    private void saveUserAsync(String username, String email, String passwordHash) {
        new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    synchronized (AuthDatabase.this) {
                        if (connection == null || connection.isClosed()) return;
                        
                        String insert = "INSERT OR IGNORE INTO users (username, email, password_hash) VALUES (?, ?, ?)";
                        try (PreparedStatement stmt = connection.prepareStatement(insert)) {
                            stmt.setString(1, username);
                            stmt.setString(2, email);
                            stmt.setString(3, passwordHash);
                            stmt.executeUpdate();
                        }
                    }
                } catch (SQLException e) {
                    plugin.getLogger().warning("[AlRabeehCore] Failed to save user: " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(plugin);
    }

    public boolean isRegistered(String username) {
        return cache.containsKey(username.toLowerCase());
    }

    public boolean verifyPassword(String username, String password) {
        AuthUser user = cache.get(username.toLowerCase());
        if (user == null) return false;
        return user.passwordHash.equals(hashPassword(password));
    }

    public AuthUser getUser(String username) {
        return cache.get(username.toLowerCase());
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return password; // Fallback
        }
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                plugin.getLogger().info("[AlRabeehCore] Database connection closed");
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("[AlRabeehCore] Error closing database: " + e.getMessage());
        }
    }

    public static class AuthUser {
        public final String username;
        public final String email;
        public final String passwordHash;

        public AuthUser(String username, String email, String passwordHash) {
            this.username = username;
            this.email = email;
            this.passwordHash = passwordHash;
        }
    }
}
