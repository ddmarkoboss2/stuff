package me.alrabeeh.core.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * Maps color names to Minecraft color codes (§).
 * Simply set a LuckPerms prefix as a color name (e.g., "orange")
 * and this utility will apply the correct color code.
 */
public class ColorMapper {
    
    private static final Map<String, String> COLOR_MAP = new HashMap<>();
    
    static {
        // Standard Minecraft color codes
        COLOR_MAP.put("black", "§0");
        COLOR_MAP.put("dark_blue", "§1");
        COLOR_MAP.put("dark_green", "§2");
        COLOR_MAP.put("dark_cyan", "§3");
        COLOR_MAP.put("dark_red", "§4");
        COLOR_MAP.put("purple", "§5");
        COLOR_MAP.put("gold", "§6");
        COLOR_MAP.put("orange", "§6");      // Alias for gold
        COLOR_MAP.put("gray", "§7");
        COLOR_MAP.put("grey", "§7");        // Alternate spelling
        COLOR_MAP.put("dark_gray", "§8");
        COLOR_MAP.put("dark_grey", "§8");
        COLOR_MAP.put("blue", "§9");
        COLOR_MAP.put("green", "§a");
        COLOR_MAP.put("cyan", "§b");
        COLOR_MAP.put("red", "§c");
        COLOR_MAP.put("pink", "§d");
        COLOR_MAP.put("magenta", "§d");    // Alias for pink
        COLOR_MAP.put("yellow", "§e");
        COLOR_MAP.put("white", "§f");
    }
    
    /**
     * Get the color code (§X) for a given color name.
     * If the color name is not found, returns white (§f).
     * 
     * @param colorName The name of the color (e.g., "orange", "blue")
     * @return The Minecraft color code (e.g., "§6")
     */
    public static String getColorCode(String colorName) {
        if (colorName == null || colorName.isEmpty()) {
            return "§f"; // Default to white
        }
        return COLOR_MAP.getOrDefault(colorName.toLowerCase(), "§f");
    }
    
    /**
     * Format a group name with a color code.
     * 
     * @param groupName The group name (e.g., "Student")
     * @param colorName The color name (e.g., "orange")
     * @return Formatted string: [§6Student§r] or similar
     */
    public static String formatGroupPrefix(String groupName, String colorName) {
        String colorCode = getColorCode(colorName);
        return "[" + colorCode + groupName + "§r]"; // §r is reset
    }
}
