package me.alrabeeh.core.managers;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;

import me.alrabeeh.core.database.AuthDatabase;
import me.alrabeeh.core.database.SethomeDatabase;

public class PluginManager {
    private static final PluginManager instance = new PluginManager();
    
    private final Map<UUID, Long> playerJoinTimes = new ConcurrentHashMap<>();
    private Location rtpPortalLocation;
    private Location rtpPos1;
    private Location rtpPos2;
    private final Map<UUID, Boolean> authenticatedPlayers = new ConcurrentHashMap<>();
    private final Map<UUID, Map<Integer, Long>> deletePendingConfirmation = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> blindnessTaskIds = new ConcurrentHashMap<>();
    
    private AuthDatabase authDatabase;
    private SethomeDatabase sethomeDatabase;
    
    private PluginManager() {}
    
    public static PluginManager getInstance() {
        return instance;
    }
    
    public void initialize(JavaPlugin plugin) {
        this.authDatabase = new AuthDatabase(plugin);
        this.sethomeDatabase = new SethomeDatabase(plugin);
    }
    
    public AuthDatabase getAuthDatabase() {
        return authDatabase;
    }
    
    public SethomeDatabase getSethomeDatabase() {
        return sethomeDatabase;
    }
    
    public void setPlayerJoinTime(UUID playerId, long time) {
        playerJoinTimes.put(playerId, time);
    }
    
    public long getPlayerJoinTime(UUID playerId) {
        return playerJoinTimes.getOrDefault(playerId, 0L);
    }
    
    public void removePlayerJoinTime(UUID playerId) {
        playerJoinTimes.remove(playerId);
    }
    
    public void setRTPPortalLocation(Location location) {
        this.rtpPortalLocation = location;
    }
    
    public Location getRTPPortalLocation() {
        return this.rtpPortalLocation;
    }
    
    public void setRTPPos1(Location pos1) {
        this.rtpPos1 = pos1;
    }
    
    public Location getRTPPos1() {
        return this.rtpPos1;
    }
    
    public void setRTPPos2(Location pos2) {
        this.rtpPos2 = pos2;
    }
    
    public Location getRTPPos2() {
        return this.rtpPos2;
    }
    
    public void setAuthenticated(UUID playerId, boolean authenticated) {
        authenticatedPlayers.put(playerId, authenticated);
        if (authenticated) {
            // Cancel blindness task when authenticated
            Integer taskId = blindnessTaskIds.remove(playerId);
            if (taskId != null) {
                org.bukkit.Bukkit.getScheduler().cancelTask(taskId);
            }
        }
    }
    
    public boolean isAuthenticated(UUID playerId) {
        return authenticatedPlayers.getOrDefault(playerId, false);
    }
    
    public boolean isRegistered(UUID playerId) {
        return authDatabase != null && authDatabase.isRegistered(playerId.toString());
    }
    
    public void setDeletePending(UUID playerId, int slot) {
        Map<Integer, Long> pending = deletePendingConfirmation.computeIfAbsent(playerId, k -> new ConcurrentHashMap<>());
        pending.put(slot, System.currentTimeMillis());
    }
    
    public boolean isDeletePending(UUID playerId, int slot) {
        Map<Integer, Long> pending = deletePendingConfirmation.get(playerId);
        if (pending == null) return false;
        Long time = pending.get(slot);
        if (time == null) return false;
        
        // 10 second timeout
        if (System.currentTimeMillis() - time > 10000) {
            pending.remove(slot);
            return false;
        }
        return true;
    }
    
    public void clearDeletePending(UUID playerId, int slot) {
        Map<Integer, Long> pending = deletePendingConfirmation.get(playerId);
        if (pending != null) {
            pending.remove(slot);
        }
    }
    
    public void setBlindnessTaskId(UUID playerId, int taskId) {
        blindnessTaskIds.put(playerId, taskId);
    }
    
    public void closeConnections() {
        if (authDatabase != null) {
            authDatabase.close();
        }
    }
}
