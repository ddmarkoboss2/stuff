package me.alrabeeh.core;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import me.alrabeeh.core.commands.HelpCommand;
import me.alrabeeh.core.commands.LoginCommand;
import me.alrabeeh.core.commands.RegisterCommand;
import me.alrabeeh.core.commands.SethomeCommand;
import me.alrabeeh.core.commands.SupportCommand;
import me.alrabeeh.core.listeners.AuthListener;
import me.alrabeeh.core.listeners.InventoryListener;
import me.alrabeeh.core.listeners.MovementListener;
import me.alrabeeh.core.listeners.PlayerListener;
import me.alrabeeh.core.managers.PluginManager;
import me.alrabeeh.core.utils.Utils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;

public class AlRabeehCore extends JavaPlugin {
    
    @Override
    public void onEnable() {
        
        // Initialize managers with plugin instance
        PluginManager.getInstance().initialize(this);
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new AuthListener(), this);
        getServer().getPluginManager().registerEvents(new InventoryListener(this), this);
        getServer().getPluginManager().registerEvents(new MovementListener(), this);
        
        // Register commands
        getCommand("support").setExecutor(new SupportCommand());
        getCommand("sethome").setExecutor(new SethomeCommand(this));
        getCommand("help").setExecutor(new HelpCommand());
        getCommand("register").setExecutor(new RegisterCommand());
        getCommand("login").setExecutor(new LoginCommand());
        
        // Schedule auto-support message every 10-15 minutes
        int delayTicks = (10 + (int)(Math.random() * 6)) * 20 * 60; // 10-15 min in ticks
        getServer().getScheduler().runTaskTimer(this, () -> {
            Component message = Utils.colorize("<green>Need help? Visit our school forums: </green>")
                    .append(Component.text("https://school-forums.example.com")
                            .clickEvent(ClickEvent.openUrl("https://school-forums.example.com")));
            for (Player player : getServer().getOnlinePlayers()) {
                player.sendMessage(message);
            }
        }, delayTicks, delayTicks);
        
        getLogger().info("AlRabeehCore has been enabled!");
    }

    @Override
    public void onDisable() {
        PluginManager.getInstance().closeConnections();
        getLogger().info("AlRabeehCore has been disabled!");
    }
    
}
