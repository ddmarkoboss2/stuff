Copy and paste this entire block into the Copilot Chat (Ctrl+Shift+I or the Chat icon on the left) as your first message:

Role: You are an expert Minecraft Plugin Developer specializing in Paper/Purpur 1.21.1 and Java 21.

Project Context: I am building the "Al Rabeeh Core" plugin for a school server with 960 students.

My Setup: > * API: Paper API 1.21.1

Main Class: me.alrabeeh.core.Main

Dependencies: LuckPerms (API), CoreProtect (API), BetterRTP.

Coding Standards:

Use modern Java 21 features.

Prioritize performance and "Async" operations where possible (to handle high player counts).

Use ChatColor or MiniMessage for messages.

Always check for nulls to prevent server crashes.

Current Task: I need to build a system that includes:

A 5-second chat delay after joining.

A custom /support command that shows a clickable link to our school forums.

An RTP portal listener that triggers BetterRTP.

I will also ask for additional implementations, Please FOLLOW THE RULES.

Please help me implement these one by one. Ready?